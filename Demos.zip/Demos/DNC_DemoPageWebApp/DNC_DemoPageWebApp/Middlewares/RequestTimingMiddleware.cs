﻿namespace DNC_DemoPageWebApp.Middlewares
{
    internal class RequestTimingMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestTimingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var startTime = DateTime.UtcNow;
            
            await _next(context);

            var endTime = DateTime.UtcNow;
            var processingTime = endTime - startTime;

            Console.WriteLine($"Request processing time: {processingTime.TotalMilliseconds} ms.");
        }
    }

    public static class RequestTimingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestTiming(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestTimingMiddleware>();
        }
    }
}
