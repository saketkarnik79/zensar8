using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNC_DemoPageWebApp.Pages
{
    public class ProductsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
