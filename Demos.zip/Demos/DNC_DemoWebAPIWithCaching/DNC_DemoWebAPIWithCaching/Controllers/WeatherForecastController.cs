using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using System.Text;

namespace DNC_DemoWebAPIWithCaching.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IOutputCacheStore _outputCacheStore;

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IOutputCacheStore outputCacheStore)
        {
            _logger = logger;
            _outputCacheStore = outputCacheStore;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        //[ResponseCache(Duration = 60, Location = ResponseCacheLocation.Client)]
        //[OutputCache(Duration = 60)]
        public IEnumerable<WeatherForecast> Get()
        {
            _outputCacheStore.SetAsync("cachedData", Encoding.UTF8.GetBytes("This is cached data."), null,
                TimeSpan.FromSeconds(60), CancellationToken.None);

            _outputCacheStore.GetAsync("cachedData", CancellationToken.None).AsTask().ContinueWith(task =>
            {
                if (task.IsCompletedSuccessfully)
                {
                    var cachedData = Encoding.UTF8.GetString(task.Result);
                    _logger.LogInformation($"Cached data: {cachedData}");
                }
            });

            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
