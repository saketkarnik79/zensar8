﻿using Microsoft.AspNetCore.Mvc;

namespace DNC_DemoMVCWebApp.Controllers
{
    public class HomeController : Controller
    {
        //public string Index()
        //{
        //    return "Hello MVC! From dynamic view created by controller!";
        //}

        //public IActionResult Index()
        //{
        //    return Content("Hello MVC! From dynamic view created by controller using ContentResult!");
        //}

        //public IActionResult Index()
        //{
        //    return Content("<h1>Hello MVC! From dynamic view created by controller using ContentResult with html content type!</h1>",
        //        "text/html");
        //}

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Index2()
        {
            //ViewData.Add("data1", "Dynamic data added in ViewData by HomeController");
            //ViewBag.data2 = "Dynamic data added in ViewBag by HomeController";
            TempData.Add("data3", "Dynamic data added in TempData by HomeController Index2 Action");
            return View();
        }

        public IActionResult Index3()
        {
            return View();
        }
    }
}
