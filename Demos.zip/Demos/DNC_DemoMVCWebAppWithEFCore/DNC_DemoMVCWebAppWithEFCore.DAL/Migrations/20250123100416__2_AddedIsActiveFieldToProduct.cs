﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DNC_DemoMVCWebAppWithEFCore.DAL.Migrations
{
    /// <inheritdoc />
    public partial class _2_AddedIsActiveFieldToProduct : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "Products",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "Products");
        }
    }
}
