﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using DNC_DemoMVCWebAppWithEFCore.Models;
using Microsoft.AspNetCore.Identity;

namespace DNC_DemoMVCWebAppWithEFCore.DAL
{
    //public class ZenInventoryDbContext: DbContext
    public class ZenInventoryDbContext: IdentityDbContext<ApplicationUser>
    {
        public DbSet<Product> Products { get; set; }

        public ZenInventoryDbContext(DbContextOptions options): base(options)
        {
            
        }
    }
}
