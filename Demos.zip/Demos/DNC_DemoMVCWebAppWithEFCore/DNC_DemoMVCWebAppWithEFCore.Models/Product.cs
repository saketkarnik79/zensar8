﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DNC_DemoMVCWebAppWithEFCore.DataAnnotations;

namespace DNC_DemoMVCWebAppWithEFCore.Models
{
    [Table("Products")]
    public class Product
    {
        [Display(Name = "Product Id")]
        [Key]
        public int Id { get; set; }

        [Display(Name = "Product Name")]
        [Required(ErrorMessage = "Product Name is missing.")]
        [MaxLength(50)]
        public string? Name { get; set; }

        [Display(Name = "Unit Price")]
        [DataType(DataType.Currency)]
        [PriceRange(1, 500000, ErrorMessage = "Unit Price must be between ₹1 & ₹1000.")]
        public float UnitPrice { get; set; }

        public bool IsActive { get; set; }

        [MaxLength(250)]
        public string? ImagePath { get; set; }
    }
}
