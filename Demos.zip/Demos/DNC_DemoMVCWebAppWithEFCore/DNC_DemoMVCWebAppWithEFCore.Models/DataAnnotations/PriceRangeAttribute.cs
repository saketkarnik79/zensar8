﻿using System.ComponentModel.DataAnnotations;

namespace DNC_DemoMVCWebAppWithEFCore.DataAnnotations
{
    public class PriceRangeAttribute: ValidationAttribute
    {
        private readonly float _minValue;
        private readonly float _maxValue;

        public PriceRangeAttribute(float minValue, float maxValue)
        {
            _minValue = minValue;
            _maxValue = maxValue;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if(value is float price && (price < _minValue || price > _maxValue))
            {
                return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}
