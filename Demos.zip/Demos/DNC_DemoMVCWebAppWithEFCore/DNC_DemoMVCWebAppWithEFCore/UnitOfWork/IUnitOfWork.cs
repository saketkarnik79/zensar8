﻿using DNC_DemoMVCWebAppWithEFCore.Repositories;

namespace DNC_DemoMVCWebAppWithEFCore.UnitOfWork
{
    public interface IUnitOfWork: IDisposable
    {
        IProductRepository Products { get; }

        Task<int> CommitAsync();
    }
}
