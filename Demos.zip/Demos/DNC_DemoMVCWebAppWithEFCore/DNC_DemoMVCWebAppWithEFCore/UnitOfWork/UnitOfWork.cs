﻿using DNC_DemoMVCWebAppWithEFCore.DAL;
using DNC_DemoMVCWebAppWithEFCore.Repositories;

namespace DNC_DemoMVCWebAppWithEFCore.UnitOfWork
{
    public class UnitOfWork: IUnitOfWork
    {
        private readonly ZenInventoryDbContext _context;

        public UnitOfWork(ZenInventoryDbContext context, IProductRepository products)
        {
            _context = context;
            Products = products;
        }

        public IProductRepository Products { get; private set; }

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
