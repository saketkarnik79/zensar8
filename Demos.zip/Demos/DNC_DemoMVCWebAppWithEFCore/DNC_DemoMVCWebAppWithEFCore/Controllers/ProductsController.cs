﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
//using DNC_DemoMVCWebAppWithEFCore.DAL;
using DNC_DemoMVCWebAppWithEFCore.Repositories;
using DNC_DemoMVCWebAppWithEFCore.UnitOfWork;
using DNC_DemoMVCWebAppWithEFCore.Models;
using Microsoft.AspNetCore.Authorization;

namespace DNC_DemoMVCWebAppWithEFCore.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        //private readonly ZenInventoryDbContext _context;
        private readonly IUnitOfWork _unitOfWork;

        //public ProductsController(ZenInventoryDbContext context)
        //{
        //    _context = context;
        //}
        public ProductsController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        // GET: Products
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            //return View(await _context.Products.ToListAsync());
            return View(await _unitOfWork.Products.GetAllAsync());
        }

        // GET: Products/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var product = await _context.Products
            //    .FirstOrDefaultAsync(m => m.Id == id);
            var product = await _unitOfWork.Products.GetAsync(id.Value);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, IFormFile? imageFile)
        {
            if (ModelState.IsValid)
            {
                if(imageFile != null)
                {
                    var fileName = Guid.NewGuid().ToString() + imageFile.FileName;
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", 
                        fileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(fileStream);
                    }
                    product.ImagePath = $"/images/{fileName}";
                }

                //_context.Add(product);
                //await _context.SaveChangesAsync();
                _unitOfWork.Products.Add(product);
                await _unitOfWork.CommitAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var product = await _context.Products.FindAsync(id);
            var product = await _unitOfWork.Products.GetAsync(id.Value);

            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product, IFormFile? imageFile)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (imageFile != null)
                    {
                        var fileName = Guid.NewGuid().ToString() + imageFile.FileName;
                        var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images",
                            fileName);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }
                        product.ImagePath = $"/images/{fileName}";
                    }
                    //_context.Update(product);
                    //await _context.SaveChangesAsync();
                    _unitOfWork.Products.Update(product);
                    await _unitOfWork.CommitAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var product = await _context.Products
            //    .FirstOrDefaultAsync(m => m.Id == id);
            var product = await _unitOfWork.Products.GetAsync(id.Value);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            //var product = await _context.Products.FindAsync(id);
            var product = await _unitOfWork.Products.GetAsync(id);
            if (product != null)
            {
                //_context.Products.Remove(product);
                _unitOfWork.Products.Delete(product);
            }

            //await _context.SaveChangesAsync();
            await _unitOfWork.CommitAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            //return _context.Products.Any(e => e.Id == id);
            return _unitOfWork.Products.GetAsync(id).Result != null;
        }
    }
}
