﻿using DNC_DemoMVCWebAppWithEFCore.DAL;
using Microsoft.EntityFrameworkCore;

namespace DNC_DemoMVCWebAppWithEFCore.Repositories
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        protected readonly ZenInventoryDbContext _context;

        public Repository(ZenInventoryDbContext context)
        {
            _context = context;
        }

        public void Add(TEntity entity)
        {
            //_context.Set<TEntity>().Add(entity);
            _context.Add(entity);
        }
        public void Delete(TEntity entity)
        {
            //_context.Set<TEntity>().Remove(entity);
            _context.Remove(entity);
        }
        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _context.Set<TEntity>().ToListAsync();
        }
        public async Task<TEntity?> GetAsync(int id)
        {
            return await _context.Set<TEntity>().FindAsync(id);
        }
        public void Update(TEntity entity)
        {
            //_context.Entry(entity).State = EntityState.Modified;
            _context.Update(entity);
        }
    }
}
