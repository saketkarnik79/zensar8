﻿using DNC_DemoMVCWebAppWithEFCore.Models;

namespace DNC_DemoMVCWebAppWithEFCore.Repositories
{
    public interface IProductRepository: IRepository<Product>
    {

    }
}
