﻿using DNC_DemoMVCWebAppWithEFCore.Models;
using DNC_DemoMVCWebAppWithEFCore.DAL;

namespace DNC_DemoMVCWebAppWithEFCore.Repositories
{
    public class ProductRepository: Repository<Product>, IProductRepository
    {
        public ProductRepository(ZenInventoryDbContext context) : base(context)
        {
        }
    }
}
