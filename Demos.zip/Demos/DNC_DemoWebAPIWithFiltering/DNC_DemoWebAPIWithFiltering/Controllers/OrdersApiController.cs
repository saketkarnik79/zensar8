﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DNC_DemoWebAPIWithFiltering.Data;
using DNC_DemoWebAPIWithFiltering.Helpers;
using DNC_DemoWebAPIWithFiltering.Models;

namespace DNC_DemoWebAPIWithFiltering.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public OrdersApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<PagedResponseHelper<Order>>> GetOrders([FromQuery] PaginationHelper pagination)
        {
            var query = _context.Orders.Take(10000).AsQueryable();
            var totalRecords = await query.CountAsync();
            var orders = await query
                .Skip((pagination.PageNumber - 1) * pagination.PageSize)
                .Take(pagination.PageSize)
                .ToListAsync();

            int totalPages = (int)Math.Ceiling(totalRecords / (double)pagination.PageSize);

            return Ok(new PagedResponseHelper<Order>(orders, pagination.PageNumber, 
                pagination.PageSize, totalRecords, totalPages));
        }
    }
}
