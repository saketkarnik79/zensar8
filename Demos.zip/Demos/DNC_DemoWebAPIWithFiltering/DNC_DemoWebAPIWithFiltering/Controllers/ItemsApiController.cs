﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DNC_DemoWebAPIWithFiltering.Models;
using DNC_DemoWebAPIWithFiltering.Data;
using Microsoft.EntityFrameworkCore;

namespace DNC_DemoWebAPIWithFiltering.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ItemsApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("{category?}/{minPrice?}/{maxPrice?}")]
        public async Task<ActionResult<IEnumerable<Item>>> GetItems([FromRoute] string? category,
            [FromRoute] decimal? minPrice, [FromRoute] decimal? maxPrice)
        {
            var query = _context.Items.AsQueryable();

            if (!string.IsNullOrWhiteSpace(category))
            {
                query = query.Where(i => i.Category == category);
            }
            if(minPrice.HasValue)
            {
                query = query.Where(i => i.Price >= minPrice.Value);
            }
            if (maxPrice.HasValue)
            {
                query = query.Where(i => i.Price <= maxPrice.Value);
            }
            return Ok(await query.ToListAsync());
        }
    }
}
