﻿using System.ComponentModel.DataAnnotations;

namespace DNC_DemoWebAPIWithFiltering.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }
        public string InvoiceNo { get; set; }

        public string StockCode { get; set; }

        public string Description { get; set; }

        public int Quantity { get; set; }

        public string InvoiceDate { get; set; }

        public decimal UnitPrice { get; set; }

        public int CustomerId { get; set; }

        public string Country { get; set; }
    }
}
