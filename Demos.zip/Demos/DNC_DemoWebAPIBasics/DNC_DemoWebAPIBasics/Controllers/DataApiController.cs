﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DNC_DemoWebAPIBasics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataApiController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetData()
        {
            return Ok(new { Message = "Hello World!" });
        }
    }
}
