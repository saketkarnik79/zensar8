﻿using System.ComponentModel.DataAnnotations;

namespace DNC_DemoWebAPIBasics2.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string? Name { get; set; }

        [StringLength(500, MinimumLength = 10)]
        public string? Description { get; set; }
        
        [Required]
        [Range(1,1000000)]
        public decimal Price { get; set; }
    }
}
