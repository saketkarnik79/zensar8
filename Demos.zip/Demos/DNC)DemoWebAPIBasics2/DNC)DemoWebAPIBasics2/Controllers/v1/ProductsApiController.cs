﻿using Microsoft.AspNetCore.Mvc;
using DNC_DemoWebAPIBasics2.Models;
using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DNC_DemoWebAPIBasics2.Controllers.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    [Authorize]
    public class ProductsApiController : ControllerBase
    {
        private static readonly List<Product> _products = new List<Product>()
        {
            new Product { Id = 1, Name = "Product 1", Price = 100 },
            new Product { Id = 2, Name = "Product 2", Price = 200 },
            new Product { Id = 3, Name = "Product 3", Price = 300 },
            new Product { Id = 4, Name = "Product 4", Price = 400 },
            new Product { Id = 5, Name = "Product 5", Price = 500 }
        };
        private readonly ILogger<ProductsApiController> _logger;

        public ProductsApiController(ILogger<ProductsApiController> logger)
        {
            _logger = logger;
        }

        // GET: api/<ProductsApiController>
        [HttpGet]
        [MapToApiVersion("1.0")]
        public IActionResult Get()
        {
            return Ok(_products);
        }

        // GET api/<ProductsApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // POST api/<ProductsApiController>
        [HttpPost]
        public IActionResult Post(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _products.Add(product);
                    return CreatedAtAction(nameof(Get), new { id = product.Id }, product);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in POST");
                    ModelState.AddModelError(string.Empty, "Error in POST");
                    return BadRequest(ModelState);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<ProductsApiController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest(product);
            }
            if (ModelState.IsValid)
            {
                try
                {
                    var oldProduct = _products.FirstOrDefault(p => p.Id == id);
                    if (oldProduct is null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        oldProduct.Name = product.Name;
                        oldProduct.Description = product.Description;
                        oldProduct.Price = product.Price;
                        return NoContent();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in POST");
                    ModelState.AddModelError(string.Empty, "Error in POST");
                    return BadRequest(ModelState);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // DELETE api/<ProductsApiController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product is null)
            {
                return NotFound();
            }
            _products.Remove(product);
            return NoContent();
        }
    }
}
