﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DNC_DemoWebAPIBasics2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalcApiController : ControllerBase
    {
        //[HttpGet]
        //[Route("{a}/{b}")]
        [HttpGet("Add/{a}/{b}")]
        public double Add(double? a, double? b)
        {
            if (a.HasValue && b.HasValue)
            {
                return a.Value + b.Value;
            }
            else
            {
                return 0;
            }
        }

        [HttpGet("Subtract/{a}/{b}")]
        public double Subtract(double? a, double? b)
        {
            if (a.HasValue && b.HasValue)
            {
                return a.Value - b.Value;
            }
            else
            {
                return 0;
            }
        }

        [HttpGet("Multiple/{a}/{b}")]
        public double Multiple(double? a, double? b)
        {
            if (a.HasValue && b.HasValue)
            {
                return a.Value * b.Value;
            }
            else
            {
                return 0;
            }
        }

        [HttpGet("Divide/{a}/{b}")]
        public double Divide(double? a, double? b)
        {
            if (a.HasValue && b.HasValue)
            {
                return a.Value / b.Value;
            }
            else
            {
                return 0;
            }
        }

        [HttpGet("Modulus/{a}/{b}")]
        public double Modulus(double? a, double? b)
        {
            if (a.HasValue && b.HasValue)
            {
                return a.Value % b.Value;
            }
            else
            {
                return 0;
            }
        }
    }
}
