﻿using Microsoft.AspNetCore.Mvc;
using DNC_DemoWebAPIBasics2.Models;
using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DNC_DemoWebAPIBasics2.Controllers.v2
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("2.0")]
    [Authorize]
    public class ProductsApiController : ControllerBase
    {
        private static readonly List<Product> _products = new List<Product>()
        {
            new Product { Id = 101, Name = "Product 101", Price = 1000 },
            new Product { Id = 102, Name = "Product 102", Price = 2000 },
            new Product { Id = 103, Name = "Product 103", Price = 3000 },
            new Product { Id = 104, Name = "Product 104", Price = 4000 },
            new Product { Id = 105, Name = "Product 105", Price = 5000 }
        };
        private readonly ILogger<ProductsApiController> _logger;

        public ProductsApiController(ILogger<ProductsApiController> logger)
        {
            _logger = logger;
        }

        // GET: api/<ProductsApiController>
        [HttpGet]
        [MapToApiVersion("2.0")]
        public IActionResult Get()
        {
            return Ok(_products);
        }

        // GET api/<ProductsApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        // POST api/<ProductsApiController>
        [HttpPost]
        public IActionResult Post(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _products.Add(product);
                    return CreatedAtAction(nameof(Get), new { id = product.Id }, product);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in POST");
                    ModelState.AddModelError(string.Empty, "Error in POST");
                    return BadRequest(ModelState);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<ProductsApiController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest(product);
            }
            if (ModelState.IsValid)
            {
                try
                {
                    var oldProduct = _products.FirstOrDefault(p => p.Id == id);
                    if (oldProduct is null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        oldProduct.Name = product.Name;
                        oldProduct.Description = product.Description;
                        oldProduct.Price = product.Price;
                        return NoContent();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in POST");
                    ModelState.AddModelError(string.Empty, "Error in POST");
                    return BadRequest(ModelState);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // DELETE api/<ProductsApiController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product is null)
            {
                return NotFound();
            }
            _products.Remove(product);
            return NoContent();
        }
    }
}
