﻿const apiUrl = 'https://localhost:7092/api';
let token = '';

async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const resultDiv = document.getElementById('result');

    try {
        const response = await fetch(`${apiUrl}/authapi/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        if (!response.ok) {
            throw new Error(`${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        token = data.token;
        resultDiv.innerHTML = 'Logged in successfully.';
    }
    catch (error) {
        resultDiv.innerHTML = `Error: ${error.message}`;
    }
}

async function fetchData(version) {
    const resultDiv = document.getElementById('result');
    if (!token) {
        resultDiv.innerHTML = 'Please log in first and then load data.'
        return;
    }
    resultDiv.innerHTML = 'Loading...';

    try {
        const response = await fetch(`${apiUrl}/${version}/productsapi`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        if (!response.ok) {
            throw new Error(`${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        resultDiv.innerHTML = `<h2>API Response</h2><pre>${JSON.stringify(data,null,2)}</pre>`;
    }
    catch (error) {
        resultDiv.innerHTML = `Error: ${error.message}`;
    }
};