﻿const apiUrl = 'https://localhost:7092/api';

async function fetchData(version, id) {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = 'Loading...';

    try {
        const response = await fetch(`${apiUrl}/${version}/productsapi/${id}`);
        if (!response.ok) {
            throw new Error(`${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        resultDiv.innerHTML = `<h2>API Response</h2><pre>${JSON.stringify(data,null,2)}</pre>`;
    }
    catch (error) {
        resultDiv.innerHTML = `Error: ${error.message}`;
    }
};