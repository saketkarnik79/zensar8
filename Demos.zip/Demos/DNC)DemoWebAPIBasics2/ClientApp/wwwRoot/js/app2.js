﻿const apiUrl = 'https://localhost:7092/api';
let token = '';

async function login() {
    const username = $('#username').val();
    const password = $('#password').val();
    const resultDiv = $('#result');

    $.ajax({
        url: `${apiUrl}/authapi/login`,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ username, password }),
        success: function (data) {
            token = data.token;
            resultDiv.html('Login successful.');
        },
        error: function (xhr, status, error) {
            resultDiv.html(`Error: ${xhr.status} - ${error}`);
        }
    });

async function fetchData(version, id) {
    const resultDiv = $('#result');
    if (!token) {
        resultDiv.html('Please login first.');
        return;
    }
    resultDiv.html('Loading...');

    $.ajax({
        URL: `${apiUrl}/${version}/productsapi/${id}`,
        Headers: {
            'X-Api-Version': version,
            'Authorization': `Bearer ${token}`
        },
        method: 'GET',
        success: function (data) {
            resultDiv.html(JSON.stringify(data,null,2));
        },
        error: function (xhr,status,error) {
            resultDiv.html(`Error: ${xhr.status} - ${error}`);
        }
    });
};