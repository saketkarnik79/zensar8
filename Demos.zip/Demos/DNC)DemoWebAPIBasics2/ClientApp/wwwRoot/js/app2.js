﻿const apiUrl = 'https://localhost:7092/api';

async function fetchData(version, id) {
    const resultDiv = $('#result');
    resultDiv.html('Loading...');

    $.ajax({
        URL: `${apiUrl}/${version}/productsapi/${id}`,
        Headers: {
            'X-Api-Version': version
        },
        method: 'GET',
        success: function (data) {
            resultDiv.html(JSON.stringify(data,null,2));
        },
        error: function (xhr,status,error) {
            resultDiv.html(`Error: ${xhr.status} - ${error}`);
        }
    });
};