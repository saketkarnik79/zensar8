import React from 'react';

const ApiVersionSelector = ({ onSelectVersion }) => {
    return (
        <div>
            <h3>Select API version</h3>
            <button onClick={() => onSelectVersion('v1')}>Fetch Version v1</button>
            <button onClick={() => onSelectVersion('v2')}>Fetch Version v2</button>
        </div>
    );
}

export default ApiVersionSelector;