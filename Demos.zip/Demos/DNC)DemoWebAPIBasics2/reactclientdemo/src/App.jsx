import React, { useState } from 'react';
import axios from 'axios';
import ApiVersionSelector from './components/ApiVersionSelector';
import ApiDataDisplay from './components/ApiDataDisplay';
import './App.css';

function App() {
    const [data, setData] = useState(null);
    const apiUrl = 'https://localhost:7092/api';

    const fetchData = async (version) => {
        try {
            const response = await axios.get(`${apiUrl}/${version}/productsapi`,
                { Headers: { 'X-Api-Version': version} });
            setData(response.data);
        } catch (error) {
            console.error('Error fetching data: ', error);
            setData({ error: 'Error fetching data.' });
        }
    }

    return (
        <div className="App">
            <h1>API Versioning Demo</h1>
            <ApiVersionSelector onSelectVersion={fetchData} />
            { data && <ApiDataDisplay data={ data } /> }
        </div>
    );
}

export default App;
