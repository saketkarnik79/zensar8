﻿using Microsoft.AspNetCore.Mvc;
using DNC_DemoMVCWebAppCallingRESTAPI.Proxies;

namespace DNC_DemoMVCWebAppCallingRESTAPI.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductsProxy _productsProxy;

        public ProductsController(ProductsProxy productsProxy)
        {
            _productsProxy = productsProxy;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productsProxy.GetProductsAsync();
            return View(products);
        }
    }
}
