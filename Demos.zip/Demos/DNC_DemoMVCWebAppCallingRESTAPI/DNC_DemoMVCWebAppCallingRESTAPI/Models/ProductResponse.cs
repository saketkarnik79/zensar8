﻿namespace DNC_DemoMVCWebAppCallingRESTAPI.Models
{
    public class ProductResponse
    {
        public List<Product> Products { get; set; }
    }
}
