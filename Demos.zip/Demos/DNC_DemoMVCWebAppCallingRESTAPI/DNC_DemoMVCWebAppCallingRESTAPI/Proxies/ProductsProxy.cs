﻿using DNC_DemoMVCWebAppCallingRESTAPI.Models;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace DNC_DemoMVCWebAppCallingRESTAPI.Proxies
{
    public class ProductsProxy
    {
        private readonly HttpClient _httpClient;
        public ProductsProxy(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task<List<Product>> GetProductsAsync()
        {
            //var products = await _httpClient.GetFromJsonAsync<List<Product>>(
            //    "https://dummyjson.com/products?select=id,title,description,price,thumbnail");
            var response = await _httpClient.GetFromJsonAsync<ProductResponse>(
                "https://dummyjson.com/products");

            return response?.Products ?? new List<Product>();
        }
    }
}
